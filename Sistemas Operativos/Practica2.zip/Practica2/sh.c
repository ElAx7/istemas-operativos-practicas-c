#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h> //para usar kill y SIGTERM

void execute_command(char *command) {
    char *args[10];
    char *token = strtok(command, " ");
    int i = 0;

    while (token != NULL) {
        args[i++] = token;
        token = strtok(NULL, " ");
    }
    args[i] = NULL;

    if (strcmp(args[0], "exit") == 0) {
        exit(0);
    } else if (strcmp(args[0], "shutdown") == 0) {
        // Termina todos los procesos
        kill(0, SIGTERM);
    } else {
        if (fork() == 0) {
            execvp(args[0], args);
            perror("execvp failed");
            exit(EXIT_FAILURE);
        } else {
            wait(NULL);
        }
    }
}

int main() {
    char command[100];

    while (1) {
        printf("sh> ");
        fgets(command, sizeof(command), stdin);
        command[strlen(command) - 1] = '\0';  // Remover el salto de línea
        execute_command(command);
    }

    return 0;
}

