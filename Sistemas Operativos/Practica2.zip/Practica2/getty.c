#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

// Función para validar usuario y contraseña
int validate_user(const char *username, const char *password) {
	FILE *file = fopen("passwd", "r"); // Abrir el archivo en modo lectura
	if (file == NULL) {
	perror("Error opening passwd file");
        return 0; // Retornar 0 si no se pudo abrir el archivo
	}

	char line[256]; // Para almacenar cada línea del archivo
	while (fgets(line, sizeof(line), file)) {
		// Separar el nombre de usuario y la contraseña por el ":"
		char *user = strtok(line, ":"); 
		char *pass = strtok(NULL, "\n"); // Leer el resto hasta el salto de línea

	// Comparar las credenciales ingresadas con las del archivo
	if (strcmp(user, username) == 0 && strcmp(pass, password) == 0) {
		fclose(file);
		 return 1; // Si coinciden, retorna 1 (validación exitosa)
		}
	}

	fclose(file); // Cerrar el archivo
	return 0; // Retorna 0 si no hay coincidencias (validación fallida)
}


void start_shell(){
	if(fork() == 0){
	//Remplazo el proceso actual con el del shell sh
	char *args[] = {"./sh", NULL};
	execvp("./sh", args);
	perror("execvp failed");
	exit(EXIT_FAILURE);
	}else {
		//Espero a que el shell termine
		wait(NULL);
	}
}

int main() {
	char username[100];
	char password[100];

	while(1){
		//Solicitar login
		printf("login: ");
		scanf("%s", username);

		//Solicitar password
		printf("password: ");
		scanf("%s", password);

		if(validate_user(username, password)) {
			printf("Login successful\n");
			start_shell();
		} else {
			printf("login failed\n");
		}
	}
	return 0;
}

