#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define NUM_GETTY 6

void start_getty(){
	if(fork() == 0){
	//Este es el hijo, reemplazamos su imagen con el
	//proceso getty en una nueva ventana xterm
	char *args[] = {"term", "-e", "./getty", NULL};
	execvp("xterm", args);
	perror("execvp failed");
	exit(EXIT_FAILURE);
	}
}

int main(){
	pid_t getty_pids[NUM_GETTY];
	int i;

	//Crear los 6 procesos getty
	for(i = 0; i < NUM_GETTY; i++){
		start_getty(i);
	}

	//Monitorear que siempre haya 6 procesos getty ejecutandose
	while(1){
		int status;
		pid_t pid = wait(&status);

		if(pid > 0){
			//Cuando un proceso hijo termina, relanzo el getty
			for(i = 0; i < NUM_GETTY; i++){
				if(getty_pids[i] == pid){
					start_getty(i);
					break;
				}
			}
		}
	}
	return 0;
}

