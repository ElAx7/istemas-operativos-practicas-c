#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <mqueue.h>
#include <fcntl.h>

#define NPROCS 20
#define SERIES_MEMBER_COUNT 200000

#define FLAGS 0
#define MAXMSG 10
#define CURMSGS 0
#define BUZON_ENTRADA "/buzon_entrada"
#define BUZON_SALIDA "/buzon_salida"
#define BUZON_MAIN "/buzon_main"

struct mq_attr attr = {FLAGS, MAXMSG, sizeof(double), CURMSGS};

// Buzones de mensajes
mqd_t buzon_entrada; // Buzón para enviar datos al proc
mqd_t buzon_salida;  // Buzón para recibir datos de proc
mqd_t buzon_main;    // Buzón para enviar resultados al main

typedef struct
{
    double sums[NPROCS];
    int proc_count;
    int start_all;
    double x_val;
    double res;
} SHARED;

SHARED *shared;

double get_member(int n, double x)
{
    int i;
    double numerator = 1;

    for (i = 0; i < n; i++)
        numerator = numerator * x;

    if (n % 2 == 0)
        return (-numerator / n);
    else
        return numerator / n;
}

// Proceso esclavo que realiza los cálculos
void proc(int proc_num)
{
    int i;
    double x_val;
    char buffer[sizeof(double)];

    // Recibe el valor de x desde el buzón de entrada
    mq_receive(buzon_entrada, buffer, attr.mq_msgsize, 0);
    x_val = *(double *)buffer; // Recibe el valor de x desde el buzón

    // Espera a que el maestro ponga la bandera en 1
    while (!(shared->start_all))
    {
    }

    // Calcula su parte de la serie
    double sum = 0;
    for (i = proc_num; i < SERIES_MEMBER_COUNT; i += NPROCS)
        sum += get_member(i + 1, x_val);

    // Incrementa la variable proc_count en memoria compartida
    shared->proc_count++;

    // Envía el resultado de su cálculo al buzón de salida
    mq_send(buzon_salida, (char *)&sum, attr.mq_msgsize, 0);
    exit(0);
}

// Proceso maestro que coordina la ejecución
void master_proc()
{
    int i;
    double res = 0;

    // Lee el valor de x desde el archivo
    FILE *fp = fopen("entrada.txt", "r");
    if (fp == NULL)
    {
        perror("Error al abrir el archivo");
        exit(1);
    }
    fscanf(fp, "%lf", &shared->x_val); // Guardamos x_val en memoria compartida
    fclose(fp);

    // Envía el valor de x a todos los procesos esclavos a través del buzón de entrada
    for (i = 0; i < NPROCS; i++)
    {
        mq_send(buzon_entrada, (char *)&shared->x_val, attr.mq_msgsize, 0);
    }

    // Activa la bandera para que los esclavos comiencen
    shared->start_all = 1;

    // Recibe los resultados de los esclavos y suma los valores
    for (i = 0; i < NPROCS; i++)
    {
        char buffer[sizeof(double)];
        mq_receive(buzon_salida, buffer, attr.mq_msgsize, 0);
        shared->sums[i] = *(double *)buffer;
        res += shared->sums[i];
    }

    // Envía el resultado final al proceso principal a través del buzón principal
    shared->res = res;
    mq_send(buzon_main, (char *)&shared->res, attr.mq_msgsize, 0);
    exit(0);
}

int main()
{
    long long start_ts, stop_ts, elapsed_time;
    struct timeval ts;
    int i, p, shmid, status;

    // Solicita y conecta la memoria compartida
    shmid = shmget(0x1234, sizeof(SHARED), 0666 | IPC_CREAT);
    shared = shmat(shmid, NULL, 0);

    // Inicializa las variables en memoria compartida
    shared->proc_count = 0;
    shared->start_all = 0;

    // Inicialización de los buzones
    mq_unlink(BUZON_ENTRADA);
    mq_unlink(BUZON_SALIDA);
    mq_unlink(BUZON_MAIN);
    buzon_entrada = mq_open(BUZON_ENTRADA, O_RDWR | O_CREAT, 0600, &attr);
    buzon_salida = mq_open(BUZON_SALIDA, O_RDWR | O_CREAT, 0600, &attr);
    buzon_main = mq_open(BUZON_MAIN, O_RDWR | O_CREAT, 0600, &attr);

    if (buzon_entrada == (mqd_t)-1 || buzon_salida == (mqd_t)-1 || buzon_main == (mqd_t)-1)
    {
        perror("Error al abrir los buzones");
        exit(1);
    }

    gettimeofday(&ts, NULL);
    start_ts = ts.tv_sec; // Tiempo inicial

    // Crea los procesos esclavos
    for (i = 0; i < NPROCS; i++)
    {
        p = fork();
        if (p == 0)
            proc(i);
    }

    // Crea el proceso maestro
    p = fork();
    if (p == 0)
        master_proc();

    printf("El recuento de ln(1 + x) miembros de la serie de Mercator es %d\n", SERIES_MEMBER_COUNT);

    // El proceso principal recibe el resultado final del proceso maestro
    char res_buffer[sizeof(double)];
    mq_receive(buzon_main, res_buffer, attr.mq_msgsize, 0);
    double res = *(double *)res_buffer;

    gettimeofday(&ts, NULL);
    stop_ts = ts.tv_sec; // Tiempo final
    elapsed_time = stop_ts - start_ts;

    printf("Tiempo = %lld segundos\n", elapsed_time);
    printf("El resultado es %10.8f\n", res);

    // Compara el resultado con la función log
    printf("Llamando a la función ln(1 + %f) = %10.8f\n", shared->x_val, log(1 + shared->x_val));

    // Cierra y elimina los buzones
    mq_close(buzon_entrada);
    mq_close(buzon_salida);
    mq_close(buzon_main);
    mq_unlink(BUZON_ENTRADA);
    mq_unlink(BUZON_SALIDA);
    mq_unlink(BUZON_MAIN);

    // Desconecta y elimina la memoria compartida
    shmdt(shared);
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}
